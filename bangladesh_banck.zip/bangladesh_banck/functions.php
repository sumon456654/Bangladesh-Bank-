<?php
	wp_enqueue_style( 'style-name', get_stylesheet_uri() );
	wp_enqueue_style( 'style-root', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
	wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

register_sidebar([
    'name'=>'header right',
    'id'=>'headerright',
    'before_widget'=>'',
    'after_widget'=>"",
]);
register_sidebar([
    'name'=>'beener all',
    'id'=>'beenerall',
    'before_widget'=>'',
    'after_widget'=>"",
]);


?>